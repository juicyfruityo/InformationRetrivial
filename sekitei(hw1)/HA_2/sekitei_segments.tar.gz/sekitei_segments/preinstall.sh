#!/bin/bash
pip install sklearn
